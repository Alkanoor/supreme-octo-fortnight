var searchData=
[
  ['getreceivebuffersize',['getReceiveBufferSize',['../class_socket.html#ae7b8bde73ff163d3a92b6cc7dcb7e5cd',1,'Socket']]],
  ['getreuseaddress',['getReuseAddress',['../class_socket.html#aee4eabe73fc1550fadca23ad910d757c',1,'Socket']]],
  ['getsendbuffersize',['getSendBufferSize',['../class_socket.html#a7f899aac444facd294ef1dcfdd2cccb8',1,'Socket']]],
  ['getseparators',['getSeparators',['../class_socket_buffer.html#a81a280c639a913b5dbfb12611f339232',1,'SocketBuffer']]],
  ['getsolinger',['getSoLinger',['../class_socket.html#abd5f4f7ec400fba1fdc7fb4482daa43a',1,'Socket']]],
  ['getsotimeout',['getSoTimeout',['../class_socket.html#a628371e91c172f1405ce39f44587ff34',1,'Socket']]],
  ['gettcpnodelay',['getTcpNoDelay',['../class_socket.html#ab5fe067d4678d1d3ff906135e2cdbbb4',1,'Socket']]],
  ['group',['Group',['../class_group.html',1,'']]]
];
