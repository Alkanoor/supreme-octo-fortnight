var searchData=
[
  ['callback',['Callback',['../class_t_c_p_server_1_1_callback.html',1,'TCPServer']]],
  ['callbackimpl',['CallbackImpl',['../class_t_c_p_server_1_1_callback_impl.html',1,'TCPServer']]],
  ['close',['close',['../class_socket.html#aef06605c6725958004116983f1a2051f',1,'Socket::close()'],['../class_server_socket.html#a3eac6d5571bb092622d328dbda2de2cf',1,'ServerSocket::close()']]],
  ['cnx',['Cnx',['../class_t_c_p_server_1_1_cnx.html',1,'TCPServer']]],
  ['connect',['connect',['../class_socket.html#a772419bd74c4fe4987d190506a64ff87',1,'Socket']]]
];
