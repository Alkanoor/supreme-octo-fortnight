var searchData=
[
  ['inputbuffer',['InputBuffer',['../struct_input_buffer.html',1,'']]]
];
