var searchData=
[
  ['isclosed',['isClosed',['../class_socket.html#a6a086cd11aba1fd114dc18008dd0c6b4',1,'Socket::isClosed()'],['../class_server_socket.html#ad5b053b711f97cfe8b56f6febc15df65',1,'ServerSocket::isClosed()']]]
];
