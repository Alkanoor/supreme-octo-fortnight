var searchData=
[
  ['deletebyname',['deleteByName',['../class_factory.html#ad0553a33a3e6bd24614b0d645f7906e4',1,'Factory']]],
  ['descriptor',['descriptor',['../class_socket.html#a92b54e2c8f3ae67af7c809dc119950cb',1,'Socket::descriptor()'],['../class_server_socket.html#a57b5b84a60906153d9755190cdfd0d39',1,'ServerSocket::descriptor()']]]
];
